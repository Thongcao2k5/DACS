/* =========================================================================
   MOTOSHOP - SEED DATA (SQL Server)
   - 6 Categories x 3 Products = 18 products
   - 6 Brands x 3 Products    = mỗi thương hiệu đúng 3 SP
   - 29 ProductVariants
   - ProductImages + VariantImages (đường dẫn local /uploads/...)

   THỨ TỰ CHẠY:
     1) Chạy file Python download_images.py để tải ảnh về thư mục /uploads/
     2) Chạy file SQL này (yêu cầu các bảng đã tồn tại)

   Lưu ý: Nếu DB của bạn KHÔNG dùng IDENTITY hoặc đang seed lần đầu
          -> cứ giữ nguyên SET IDENTITY_INSERT.
          Nếu đã có dữ liệu -> bỏ các dòng IDENTITY_INSERT và để DB tự sinh ID,
          rồi đồng bộ lại các FK ở dưới.
   ========================================================================= */

USE [MotoShop];
GO

SET NOCOUNT ON;
GO

/* -------------------------------------------------------------------------
   1) UNITS - đơn vị tính
   ------------------------------------------------------------------------- */
SET IDENTITY_INSERT Units ON;
INSERT INTO Units (UnitId, UnitName, Symbol) VALUES
(1, N'Lít',  N'L'),
(2, N'Cái',  N'cái'),
(3, N'Bộ',   N'bộ'),
(4, N'Hộp',  N'hộp'),
(5, N'Chai', N'chai');
SET IDENTITY_INSERT Units OFF;
GO

/* -------------------------------------------------------------------------
   2) CATEGORIES - danh mục
   ------------------------------------------------------------------------- */
SET IDENTITY_INSERT Categories ON;
INSERT INTO Categories (CategoryId, CategoryName, Slug, ParentId, Description, ImageUrl, Icon, IsActive) VALUES
(1, N'Nhớt & Dầu nhờn', N'nhot-dau-nhon', NULL, N'Các loại nhớt động cơ, dầu nhờn cao cấp cho xe máy',
    N'/uploads/categories/nhot-dau-nhon.jpg', N'fa-oil-can', 1),
(2, N'Lốp xe',          N'lop-xe',         NULL, N'Lốp xe máy chính hãng, đa dạng kích cỡ',
    N'/uploads/categories/lop-xe.jpg', N'fa-circle-notch', 1),
(3, N'Mũ bảo hiểm',     N'mu-bao-hiem',    NULL, N'Mũ bảo hiểm an toàn đạt chuẩn quốc tế',
    N'/uploads/categories/mu-bao-hiem.jpg', N'fa-hard-hat', 1),
(4, N'Ắc quy',          N'ac-quy',         NULL, N'Ắc quy xe máy bền bỉ, khởi động khỏe',
    N'/uploads/categories/ac-quy.jpg', N'fa-car-battery', 1),
(5, N'Phụ tùng máy',    N'phu-tung-may',   NULL, N'Phụ tùng máy chính hãng cho xe máy',
    N'/uploads/categories/phu-tung-may.jpg', N'fa-cogs', 1),
(6, N'Phụ kiện xe',     N'phu-kien-xe',    NULL, N'Phụ kiện trang trí và nâng cấp xe máy',
    N'/uploads/categories/phu-kien-xe.jpg', N'fa-motorcycle', 1);
SET IDENTITY_INSERT Categories OFF;
GO

/* -------------------------------------------------------------------------
   3) BRANDS - thương hiệu
   ------------------------------------------------------------------------- */
SET IDENTITY_INSERT Brands ON;
INSERT INTO Brands (BrandId, BrandName, LogoUrl, Description) VALUES
(1, N'Honda',    N'/uploads/brands/honda.png',    N'Tập đoàn Honda - Nhật Bản, dẫn đầu công nghệ xe máy'),
(2, N'Yamaha',   N'/uploads/brands/yamaha.png',   N'Yamaha Motor - Nhật Bản, thiết kế thể thao đẳng cấp'),
(3, N'Castrol',  N'/uploads/brands/castrol.png',  N'Castrol - Anh Quốc, hãng dầu nhớt hàng đầu thế giới'),
(4, N'Michelin', N'/uploads/brands/michelin.png', N'Michelin - Pháp, lốp xe chất lượng cao toàn cầu'),
(5, N'Yuasa',    N'/uploads/brands/yuasa.png',    N'GS Yuasa - Nhật Bản, ắc quy bền bỉ số 1'),
(6, N'AGV',      N'/uploads/brands/agv.png',      N'AGV - Ý, mũ bảo hiểm an toàn cho tay đua MotoGP');
SET IDENTITY_INSERT Brands OFF;
GO

/* -------------------------------------------------------------------------
   4) PRODUCTS - 18 sản phẩm
   ------------------------------------------------------------------------- */
SET IDENTITY_INSERT Products ON;
INSERT INTO Products (ProductId, CategoryId, BrandId, ProductName, Slug, Description, IsFeatured, IsActive, CreatedDate, IsDeleted, SoldCount) VALUES
-- ===== NHỚT (Cat 1) - Castrol (Brand 3) - 3 SP =====
(1,  1, 3, N'Nhớt Castrol POWER 1 4T 10W-40',
    N'nhot-castrol-power-1-4t-10w40',
    N'Nhớt tổng hợp cao cấp Castrol POWER 1 4T 10W-40 dành cho xe máy thể thao. Công nghệ Trizone giúp tăng tốc nhanh, bền bỉ động cơ.',
    1, 1, GETDATE(), 0, 156),
(2,  1, 3, N'Nhớt Castrol ACTIV 4T 20W-40',
    N'nhot-castrol-activ-4t-20w40',
    N'Nhớt khoáng Castrol ACTIV 4T 20W-40 cho xe số phổ thông. Bảo vệ động cơ khỏi ăn mòn, kéo dài tuổi thọ máy.',
    0, 1, GETDATE(), 0, 89),
(3,  1, 3, N'Nhớt Castrol MAGNATEC 4T 10W-40',
    N'nhot-castrol-magnatec-4t-10w40',
    N'Nhớt bán tổng hợp Castrol MAGNATEC với phân tử thông minh bám dính trên bề mặt máy, bảo vệ ngay từ lúc khởi động.',
    1, 1, GETDATE(), 0, 124),

-- ===== LỐP XE (Cat 2) - Michelin (Brand 4) - 3 SP =====
(4,  2, 4, N'Lốp Michelin City Grip 2 90/90-14',
    N'lop-michelin-city-grip-2-90-90-14',
    N'Lốp xe tay ga Michelin City Grip 2 kích thước 90/90-14, độ bám đường tốt trên cả mặt đường ướt và khô.',
    1, 1, GETDATE(), 0, 67),
(5,  2, 4, N'Lốp Michelin Pilot Street 2 100/80-17',
    N'lop-michelin-pilot-street-2-100-80-17',
    N'Lốp Michelin Pilot Street 2 cho xe côn tay 100/80-17, hiệu suất cao trong điều kiện đường phố Việt Nam.',
    1, 1, GETDATE(), 0, 45),
(6,  2, 4, N'Lốp Michelin Power Pure SC 120/70-12',
    N'lop-michelin-power-pure-sc-120-70-12',
    N'Lốp thể thao Michelin Power Pure SC dành cho xe tay ga thể thao 120/70-12.',
    0, 1, GETDATE(), 0, 23),

-- ===== MŨ BẢO HIỂM (Cat 3) - AGV (Brand 6) - 3 SP =====
(7,  3, 6, N'Mũ bảo hiểm AGV K1 S Solid',
    N'mu-bao-hiem-agv-k1-s-solid',
    N'Mũ bảo hiểm fullface AGV K1 S, vỏ composite siêu nhẹ, đệm thoáng khí, chuẩn ECE 22.06.',
    1, 1, GETDATE(), 0, 78),
(8,  3, 6, N'Mũ bảo hiểm AGV K3 SV Rossi',
    N'mu-bao-hiem-agv-k3-sv-rossi',
    N'Mũ AGV K3 SV phiên bản đặc biệt, kính chống tia UV, hệ thống thông gió 5 vị trí.',
    1, 1, GETDATE(), 0, 92),
(9,  3, 6, N'Mũ bảo hiểm AGV Pista GP RR',
    N'mu-bao-hiem-agv-pista-gp-rr',
    N'Mũ bảo hiểm cao cấp AGV Pista GP RR, vỏ sợi carbon 100%, dùng trong giải MotoGP chuyên nghiệp.',
    1, 1, GETDATE(), 0, 12),

-- ===== ẮC QUY (Cat 4) - Yuasa (Brand 5) - 3 SP =====
(10, 4, 5, N'Ắc quy Yuasa YTX7A-BS 12V-7Ah',
    N'ac-quy-yuasa-ytx7a-bs-12v-7ah',
    N'Ắc quy khô Yuasa YTX7A-BS, dung lượng 12V-7Ah, dùng cho Air Blade, Vario, Lead, SH Mode.',
    1, 1, GETDATE(), 0, 234),
(11, 4, 5, N'Ắc quy Yuasa YB9-B 12V-9Ah',
    N'ac-quy-yuasa-yb9-b-12v-9ah',
    N'Ắc quy nước Yuasa YB9-B 12V-9Ah cho xe côn tay, độ bền cao, khởi động khỏe.',
    0, 1, GETDATE(), 0, 167),
(12, 4, 5, N'Ắc quy Yuasa YTZ10S 12V-8.6Ah',
    N'ac-quy-yuasa-ytz10s-12v-8-6ah',
    N'Ắc quy Yuasa YTZ10S công nghệ AGM, dung lượng 8.6Ah, không cần bảo dưỡng.',
    1, 1, GETDATE(), 0, 89),

-- ===== PHỤ TÙNG MÁY (Cat 5) - Honda x2 + Yamaha x1 - 3 SP =====
(13, 5, 1, N'Bộ nhông xích Honda Wave Alpha',
    N'bo-nhong-xich-honda-wave-alpha',
    N'Bộ nhông xích chính hãng Honda Wave Alpha, gồm nhông trước, nhông sau và xích DID.',
    0, 1, GETDATE(), 0, 134),
(14, 5, 1, N'Bố thắng đĩa Honda CBR150R',
    N'bo-thang-dia-honda-cbr150r',
    N'Bộ má phanh đĩa chính hãng Honda CBR150R, ma sát cao, êm và bền.',
    1, 1, GETDATE(), 0, 78),
(15, 5, 2, N'Lọc gió Yamaha Exciter 150',
    N'loc-gio-yamaha-exciter-150',
    N'Lọc gió chính hãng Yamaha cho Exciter 150, lọc bụi mịn, tăng hiệu suất máy.',
    0, 1, GETDATE(), 0, 201),

-- ===== PHỤ KIỆN XE (Cat 6) - Honda x1 + Yamaha x2 - 3 SP =====
(16, 6, 1, N'Gương chiếu hậu Honda Vario 150',
    N'guong-chieu-hau-honda-vario-150',
    N'Cặp gương chiếu hậu chính hãng Honda Vario 150, kiểu dáng thể thao, chống chói.',
    1, 1, GETDATE(), 0, 56),
(17, 6, 2, N'Bao tay Yamaha Exciter 155 VVA',
    N'bao-tay-yamaha-exciter-155-vva',
    N'Bao tay cao su chống trượt cho Yamaha Exciter 155 VVA, ôm sát, êm tay.',
    0, 1, GETDATE(), 0, 145),
(18, 6, 2, N'Đèn LED trợ sáng Yamaha 30W',
    N'den-led-tro-sang-yamaha-30w',
    N'Đèn LED trợ sáng cho Yamaha công suất 30W, ánh sáng trắng/vàng, chống nước IP67.',
    1, 1, GETDATE(), 0, 98);
SET IDENTITY_INSERT Products OFF;
GO

/* -------------------------------------------------------------------------
   5) PRODUCT VARIANTS - 29 biến thể
   ------------------------------------------------------------------------- */
SET IDENTITY_INSERT ProductVariants ON;
INSERT INTO ProductVariants (ProductVariantId, ProductId, BaseUnitId, SKU, VariantName, Price, OriginalPrice, CostPrice, StockQuantity, ImageUrl, MinStockLevel) VALUES
-- P1 Castrol POWER 1 (2 variants)
(1,  1, 5, N'NHOT-CASTROL-POWER1-1L',  N'1 Lít',   180000, 200000, 130000, 50,  N'/uploads/variants/nhot-castrol-power1-1l-1.jpg',  10),
(2,  1, 5, N'NHOT-CASTROL-POWER1-08L', N'0.8 Lít', 150000, 170000, 110000, 60,  N'/uploads/variants/nhot-castrol-power1-08l-1.jpg', 10),

-- P2 Castrol ACTIV (2 variants)
(3,  2, 5, N'NHOT-CASTROL-ACTIV-1L',   N'1 Lít',   95000,  110000, 70000,  80,  N'/uploads/variants/nhot-castrol-activ-1l-1.jpg',   15),
(4,  2, 5, N'NHOT-CASTROL-ACTIV-08L',  N'0.8 Lít', 80000,  90000,  60000,  90,  N'/uploads/variants/nhot-castrol-activ-08l-1.jpg',  15),

-- P3 Castrol MAGNATEC (2 variants)
(5,  3, 5, N'NHOT-CASTROL-MAG-1L',     N'1 Lít',   220000, 240000, 165000, 40,  N'/uploads/variants/nhot-castrol-mag-1l-1.jpg',     10),
(6,  3, 5, N'NHOT-CASTROL-MAG-08L',    N'0.8 Lít', 185000, 200000, 140000, 45,  N'/uploads/variants/nhot-castrol-mag-08l-1.jpg',    10),

-- P4 Michelin City Grip 2 (1 variant)
(7,  4, 2, N'LOP-MICH-CG2-90-90-14',   N'90/90-14', 750000, 850000, 580000, 25, N'/uploads/variants/lop-mich-cg2-90-90-14-1.jpg', 5),

-- P5 Michelin Pilot Street 2 (1 variant)
(8,  5, 2, N'LOP-MICH-PS2-100-80-17',  N'100/80-17', 980000, 1100000, 750000, 18, N'/uploads/variants/lop-mich-ps2-100-80-17-1.jpg', 5),

-- P6 Michelin Power Pure SC (1 variant)
(9,  6, 2, N'LOP-MICH-PP-120-70-12',   N'120/70-12', 1250000, 1400000, 950000, 12, N'/uploads/variants/lop-mich-pp-120-70-12-1.jpg', 3),

-- P7 AGV K1 S (3 variants)
(10, 7, 2, N'MU-AGV-K1S-M',            N'Size M',  4500000, 5000000, 3200000, 8,  N'/uploads/variants/mu-agv-k1s-m-1.jpg',  2),
(11, 7, 2, N'MU-AGV-K1S-L',            N'Size L',  4500000, 5000000, 3200000, 12, N'/uploads/variants/mu-agv-k1s-l-1.jpg',  2),
(12, 7, 2, N'MU-AGV-K1S-XL',           N'Size XL', 4500000, 5000000, 3200000, 6,  N'/uploads/variants/mu-agv-k1s-xl-1.jpg', 2),

-- P8 AGV K3 SV (3 variants)
(13, 8, 2, N'MU-AGV-K3SV-M',           N'Size M',  6800000, 7500000, 5000000, 5,  N'/uploads/variants/mu-agv-k3sv-m-1.jpg',  2),
(14, 8, 2, N'MU-AGV-K3SV-L',           N'Size L',  6800000, 7500000, 5000000, 9,  N'/uploads/variants/mu-agv-k3sv-l-1.jpg',  2),
(15, 8, 2, N'MU-AGV-K3SV-XL',          N'Size XL', 6800000, 7500000, 5000000, 4,  N'/uploads/variants/mu-agv-k3sv-xl-1.jpg', 2),

-- P9 AGV Pista GP RR (2 variants)
(16, 9, 2, N'MU-AGV-PISTA-L',          N'Size L',  35000000, 38000000, 26000000, 3, N'/uploads/variants/mu-agv-pista-l-1.jpg',  1),
(17, 9, 2, N'MU-AGV-PISTA-XL',         N'Size XL', 35000000, 38000000, 26000000, 2, N'/uploads/variants/mu-agv-pista-xl-1.jpg', 1),

-- P10 Yuasa YTX7A-BS (1 variant)
(18, 10, 2, N'ACQUY-YUASA-YTX7A',      N'12V-7Ah', 480000, 550000, 350000, 35, N'/uploads/variants/acquy-yuasa-ytx7a-1.jpg', 8),

-- P11 Yuasa YB9-B (1 variant)
(19, 11, 2, N'ACQUY-YUASA-YB9B',       N'12V-9Ah', 520000, 580000, 380000, 28, N'/uploads/variants/acquy-yuasa-yb9b-1.jpg', 6),

-- P12 Yuasa YTZ10S (1 variant)
(20, 12, 2, N'ACQUY-YUASA-YTZ10S',     N'12V-8.6Ah AGM', 850000, 950000, 620000, 18, N'/uploads/variants/acquy-yuasa-ytz10s-1.jpg', 5),

-- P13 Bộ nhông xích Honda Wave (1 variant)
(21, 13, 3, N'PT-HONDA-NHONG-WAVE',    N'Bộ tiêu chuẩn', 380000, 450000, 280000, 25, N'/uploads/variants/pt-honda-nhong-wave-1.jpg', 5),

-- P14 Bố thắng đĩa Honda CBR (1 variant)
(22, 14, 2, N'PT-HONDA-BO-CBR150',     N'Trước/Sau',     220000, 260000, 160000, 40, N'/uploads/variants/pt-honda-bo-cbr150-1.jpg', 8),

-- P15 Lọc gió Yamaha Exciter (1 variant)
(23, 15, 2, N'PT-YAMAHA-LOCGIO-EX150', N'Tiêu chuẩn',    85000,  100000, 60000,  60, N'/uploads/variants/pt-yamaha-locgio-ex150-1.jpg', 12),

-- P16 Gương Honda Vario (2 variants)
(24, 16, 3, N'PK-HONDA-GUONG-VARIO-DEN', N'Màu Đen',  280000, 320000, 200000, 30, N'/uploads/variants/pk-honda-guong-vario-den-1.jpg', 6),
(25, 16, 3, N'PK-HONDA-GUONG-VARIO-BAC', N'Màu Bạc',  280000, 320000, 200000, 22, N'/uploads/variants/pk-honda-guong-vario-bac-1.jpg', 6),

-- P17 Bao tay Yamaha Exciter (2 variants)
(26, 17, 2, N'PK-YAMAHA-BAOTAY-EX-DEN',  N'Màu Đen',  120000, 140000, 85000,  55, N'/uploads/variants/pk-yamaha-baotay-ex-den-1.jpg', 10),
(27, 17, 2, N'PK-YAMAHA-BAOTAY-EX-DO',   N'Màu Đỏ',   120000, 140000, 85000,  48, N'/uploads/variants/pk-yamaha-baotay-ex-do-1.jpg',  10),

-- P18 Đèn LED Yamaha (2 variants)
(28, 18, 2, N'PK-YAMAHA-LED-30W-TRANG', N'Ánh sáng Trắng', 350000, 420000, 250000, 35, N'/uploads/variants/pk-yamaha-led-30w-trang-1.jpg', 8),
(29, 18, 2, N'PK-YAMAHA-LED-30W-VANG',  N'Ánh sáng Vàng',  350000, 420000, 250000, 28, N'/uploads/variants/pk-yamaha-led-30w-vang-1.jpg',  8);
SET IDENTITY_INSERT ProductVariants OFF;
GO

/* -------------------------------------------------------------------------
   6) PRODUCT IMAGES - 2 ảnh chính / sản phẩm (36 ảnh)
   ------------------------------------------------------------------------- */
SET IDENTITY_INSERT ProductImages ON;
INSERT INTO ProductImages (ImageId, ProductId, ImageUrl, IsPrimary, DisplayOrder, MediaType, VideoUrl) VALUES
-- P1
(1,  1, N'/uploads/products/nhot-castrol-power-1-4t-10w40-1.jpg', 1, 1, N'image', NULL),
(2,  1, N'/uploads/products/nhot-castrol-power-1-4t-10w40-2.jpg', 0, 2, N'image', NULL),
-- P2
(3,  2, N'/uploads/products/nhot-castrol-activ-4t-20w40-1.jpg',   1, 1, N'image', NULL),
(4,  2, N'/uploads/products/nhot-castrol-activ-4t-20w40-2.jpg',   0, 2, N'image', NULL),
-- P3
(5,  3, N'/uploads/products/nhot-castrol-magnatec-4t-10w40-1.jpg', 1, 1, N'image', NULL),
(6,  3, N'/uploads/products/nhot-castrol-magnatec-4t-10w40-2.jpg', 0, 2, N'image', NULL),
-- P4
(7,  4, N'/uploads/products/lop-michelin-city-grip-2-90-90-14-1.jpg', 1, 1, N'image', NULL),
(8,  4, N'/uploads/products/lop-michelin-city-grip-2-90-90-14-2.jpg', 0, 2, N'image', NULL),
-- P5
(9,  5, N'/uploads/products/lop-michelin-pilot-street-2-100-80-17-1.jpg', 1, 1, N'image', NULL),
(10, 5, N'/uploads/products/lop-michelin-pilot-street-2-100-80-17-2.jpg', 0, 2, N'image', NULL),
-- P6
(11, 6, N'/uploads/products/lop-michelin-power-pure-sc-120-70-12-1.jpg', 1, 1, N'image', NULL),
(12, 6, N'/uploads/products/lop-michelin-power-pure-sc-120-70-12-2.jpg', 0, 2, N'image', NULL),
-- P7
(13, 7, N'/uploads/products/mu-bao-hiem-agv-k1-s-solid-1.jpg', 1, 1, N'image', NULL),
(14, 7, N'/uploads/products/mu-bao-hiem-agv-k1-s-solid-2.jpg', 0, 2, N'image', NULL),
-- P8
(15, 8, N'/uploads/products/mu-bao-hiem-agv-k3-sv-rossi-1.jpg', 1, 1, N'image', NULL),
(16, 8, N'/uploads/products/mu-bao-hiem-agv-k3-sv-rossi-2.jpg', 0, 2, N'image', NULL),
-- P9
(17, 9, N'/uploads/products/mu-bao-hiem-agv-pista-gp-rr-1.jpg', 1, 1, N'image', NULL),
(18, 9, N'/uploads/products/mu-bao-hiem-agv-pista-gp-rr-2.jpg', 0, 2, N'image', NULL),
-- P10
(19, 10, N'/uploads/products/ac-quy-yuasa-ytx7a-bs-12v-7ah-1.jpg', 1, 1, N'image', NULL),
(20, 10, N'/uploads/products/ac-quy-yuasa-ytx7a-bs-12v-7ah-2.jpg', 0, 2, N'image', NULL),
-- P11
(21, 11, N'/uploads/products/ac-quy-yuasa-yb9-b-12v-9ah-1.jpg', 1, 1, N'image', NULL),
(22, 11, N'/uploads/products/ac-quy-yuasa-yb9-b-12v-9ah-2.jpg', 0, 2, N'image', NULL),
-- P12
(23, 12, N'/uploads/products/ac-quy-yuasa-ytz10s-12v-8-6ah-1.jpg', 1, 1, N'image', NULL),
(24, 12, N'/uploads/products/ac-quy-yuasa-ytz10s-12v-8-6ah-2.jpg', 0, 2, N'image', NULL),
-- P13
(25, 13, N'/uploads/products/bo-nhong-xich-honda-wave-alpha-1.jpg', 1, 1, N'image', NULL),
(26, 13, N'/uploads/products/bo-nhong-xich-honda-wave-alpha-2.jpg', 0, 2, N'image', NULL),
-- P14
(27, 14, N'/uploads/products/bo-thang-dia-honda-cbr150r-1.jpg', 1, 1, N'image', NULL),
(28, 14, N'/uploads/products/bo-thang-dia-honda-cbr150r-2.jpg', 0, 2, N'image', NULL),
-- P15
(29, 15, N'/uploads/products/loc-gio-yamaha-exciter-150-1.jpg', 1, 1, N'image', NULL),
(30, 15, N'/uploads/products/loc-gio-yamaha-exciter-150-2.jpg', 0, 2, N'image', NULL),
-- P16
(31, 16, N'/uploads/products/guong-chieu-hau-honda-vario-150-1.jpg', 1, 1, N'image', NULL),
(32, 16, N'/uploads/products/guong-chieu-hau-honda-vario-150-2.jpg', 0, 2, N'image', NULL),
-- P17
(33, 17, N'/uploads/products/bao-tay-yamaha-exciter-155-vva-1.jpg', 1, 1, N'image', NULL),
(34, 17, N'/uploads/products/bao-tay-yamaha-exciter-155-vva-2.jpg', 0, 2, N'image', NULL),
-- P18
(35, 18, N'/uploads/products/den-led-tro-sang-yamaha-30w-1.jpg', 1, 1, N'image', NULL),
(36, 18, N'/uploads/products/den-led-tro-sang-yamaha-30w-2.jpg', 0, 2, N'image', NULL);
SET IDENTITY_INSERT ProductImages OFF;
GO

/* -------------------------------------------------------------------------
   7) VARIANT IMAGES - 2 ảnh / biến thể (58 ảnh)
   ------------------------------------------------------------------------- */
SET IDENTITY_INSERT VariantImages ON;
INSERT INTO VariantImages (VariantImageId, ProductVariantId, ImageUrl, IsPrimary, DisplayOrder) VALUES
(1,  1,  N'/uploads/variants/nhot-castrol-power1-1l-1.jpg',  1, 1),
(2,  1,  N'/uploads/variants/nhot-castrol-power1-1l-2.jpg',  0, 2),
(3,  2,  N'/uploads/variants/nhot-castrol-power1-08l-1.jpg', 1, 1),
(4,  2,  N'/uploads/variants/nhot-castrol-power1-08l-2.jpg', 0, 2),
(5,  3,  N'/uploads/variants/nhot-castrol-activ-1l-1.jpg',   1, 1),
(6,  3,  N'/uploads/variants/nhot-castrol-activ-1l-2.jpg',   0, 2),
(7,  4,  N'/uploads/variants/nhot-castrol-activ-08l-1.jpg',  1, 1),
(8,  4,  N'/uploads/variants/nhot-castrol-activ-08l-2.jpg',  0, 2),
(9,  5,  N'/uploads/variants/nhot-castrol-mag-1l-1.jpg',     1, 1),
(10, 5,  N'/uploads/variants/nhot-castrol-mag-1l-2.jpg',     0, 2),
(11, 6,  N'/uploads/variants/nhot-castrol-mag-08l-1.jpg',    1, 1),
(12, 6,  N'/uploads/variants/nhot-castrol-mag-08l-2.jpg',    0, 2),
(13, 7,  N'/uploads/variants/lop-mich-cg2-90-90-14-1.jpg',   1, 1),
(14, 7,  N'/uploads/variants/lop-mich-cg2-90-90-14-2.jpg',   0, 2),
(15, 8,  N'/uploads/variants/lop-mich-ps2-100-80-17-1.jpg',  1, 1),
(16, 8,  N'/uploads/variants/lop-mich-ps2-100-80-17-2.jpg',  0, 2),
(17, 9,  N'/uploads/variants/lop-mich-pp-120-70-12-1.jpg',   1, 1),
(18, 9,  N'/uploads/variants/lop-mich-pp-120-70-12-2.jpg',   0, 2),
(19, 10, N'/uploads/variants/mu-agv-k1s-m-1.jpg',  1, 1),
(20, 10, N'/uploads/variants/mu-agv-k1s-m-2.jpg',  0, 2),
(21, 11, N'/uploads/variants/mu-agv-k1s-l-1.jpg',  1, 1),
(22, 11, N'/uploads/variants/mu-agv-k1s-l-2.jpg',  0, 2),
(23, 12, N'/uploads/variants/mu-agv-k1s-xl-1.jpg', 1, 1),
(24, 12, N'/uploads/variants/mu-agv-k1s-xl-2.jpg', 0, 2),
(25, 13, N'/uploads/variants/mu-agv-k3sv-m-1.jpg',  1, 1),
(26, 13, N'/uploads/variants/mu-agv-k3sv-m-2.jpg',  0, 2),
(27, 14, N'/uploads/variants/mu-agv-k3sv-l-1.jpg',  1, 1),
(28, 14, N'/uploads/variants/mu-agv-k3sv-l-2.jpg',  0, 2),
(29, 15, N'/uploads/variants/mu-agv-k3sv-xl-1.jpg', 1, 1),
(30, 15, N'/uploads/variants/mu-agv-k3sv-xl-2.jpg', 0, 2),
(31, 16, N'/uploads/variants/mu-agv-pista-l-1.jpg',  1, 1),
(32, 16, N'/uploads/variants/mu-agv-pista-l-2.jpg',  0, 2),
(33, 17, N'/uploads/variants/mu-agv-pista-xl-1.jpg', 1, 1),
(34, 17, N'/uploads/variants/mu-agv-pista-xl-2.jpg', 0, 2),
(35, 18, N'/uploads/variants/acquy-yuasa-ytx7a-1.jpg',  1, 1),
(36, 18, N'/uploads/variants/acquy-yuasa-ytx7a-2.jpg',  0, 2),
(37, 19, N'/uploads/variants/acquy-yuasa-yb9b-1.jpg',   1, 1),
(38, 19, N'/uploads/variants/acquy-yuasa-yb9b-2.jpg',   0, 2),
(39, 20, N'/uploads/variants/acquy-yuasa-ytz10s-1.jpg', 1, 1),
(40, 20, N'/uploads/variants/acquy-yuasa-ytz10s-2.jpg', 0, 2),
(41, 21, N'/uploads/variants/pt-honda-nhong-wave-1.jpg',    1, 1),
(42, 21, N'/uploads/variants/pt-honda-nhong-wave-2.jpg',    0, 2),
(43, 22, N'/uploads/variants/pt-honda-bo-cbr150-1.jpg',     1, 1),
(44, 22, N'/uploads/variants/pt-honda-bo-cbr150-2.jpg',     0, 2),
(45, 23, N'/uploads/variants/pt-yamaha-locgio-ex150-1.jpg', 1, 1),
(46, 23, N'/uploads/variants/pt-yamaha-locgio-ex150-2.jpg', 0, 2),
(47, 24, N'/uploads/variants/pk-honda-guong-vario-den-1.jpg', 1, 1),
(48, 24, N'/uploads/variants/pk-honda-guong-vario-den-2.jpg', 0, 2),
(49, 25, N'/uploads/variants/pk-honda-guong-vario-bac-1.jpg', 1, 1),
(50, 25, N'/uploads/variants/pk-honda-guong-vario-bac-2.jpg', 0, 2),
(51, 26, N'/uploads/variants/pk-yamaha-baotay-ex-den-1.jpg',  1, 1),
(52, 26, N'/uploads/variants/pk-yamaha-baotay-ex-den-2.jpg',  0, 2),
(53, 27, N'/uploads/variants/pk-yamaha-baotay-ex-do-1.jpg',   1, 1),
(54, 27, N'/uploads/variants/pk-yamaha-baotay-ex-do-2.jpg',   0, 2),
(55, 28, N'/uploads/variants/pk-yamaha-led-30w-trang-1.jpg',  1, 1),
(56, 28, N'/uploads/variants/pk-yamaha-led-30w-trang-2.jpg',  0, 2),
(57, 29, N'/uploads/variants/pk-yamaha-led-30w-vang-1.jpg',   1, 1),
(58, 29, N'/uploads/variants/pk-yamaha-led-30w-vang-2.jpg',   0, 2);
SET IDENTITY_INSERT VariantImages OFF;
GO

/* -------------------------------------------------------------------------
   8) PRODUCT SPECIFICATIONS - thông số kỹ thuật mẫu
   ------------------------------------------------------------------------- */
SET IDENTITY_INSERT ProductSpecifications ON;
INSERT INTO ProductSpecifications (SpecId, ProductId, SpecName, SpecValue, DisplayOrder) VALUES
-- Nhớt
(1, 1, N'Loại nhớt',  N'Tổng hợp toàn phần', 1),
(2, 1, N'Độ nhớt',    N'10W-40',             2),
(3, 1, N'Tiêu chuẩn', N'API SN, JASO MA2',   3),
(4, 2, N'Loại nhớt',  N'Khoáng',             1),
(5, 2, N'Độ nhớt',    N'20W-40',             2),
(6, 3, N'Loại nhớt',  N'Bán tổng hợp',       1),
(7, 3, N'Độ nhớt',    N'10W-40',             2),
-- Lốp xe
(8,  4, N'Kích cỡ', N'90/90-14',  1),
(9,  4, N'Loại',    N'Không ruột', 2),
(10, 5, N'Kích cỡ', N'100/80-17', 1),
(11, 6, N'Kích cỡ', N'120/70-12', 1),
-- Mũ bảo hiểm
(12, 7, N'Chuẩn an toàn', N'ECE 22.06',  1),
(13, 7, N'Vật liệu vỏ',   N'Composite',  2),
(14, 8, N'Chuẩn an toàn', N'ECE 22.06',  1),
(15, 9, N'Vật liệu vỏ',   N'Sợi Carbon', 1),
-- Ắc quy
(16, 10, N'Điện áp',    N'12V',            1),
(17, 10, N'Dung lượng', N'7Ah',            2),
(18, 10, N'Loại',       N'Khô (MF)',       3),
(19, 11, N'Điện áp',    N'12V',            1),
(20, 11, N'Dung lượng', N'9Ah',            2),
(21, 12, N'Điện áp',    N'12V',            1),
(22, 12, N'Dung lượng', N'8.6Ah',          2),
(23, 12, N'Công nghệ',  N'AGM',            3);
SET IDENTITY_INSERT ProductSpecifications OFF;
GO

/* -------------------------------------------------------------------------
   9) PRODUCT TAGS - thẻ tag
   ------------------------------------------------------------------------- */
SET IDENTITY_INSERT ProductTags ON;
INSERT INTO ProductTags (TagId, ProductId, TagName) VALUES
(1,  1, N'nhớt cao cấp'),
(2,  1, N'tổng hợp'),
(3,  2, N'nhớt phổ thông'),
(4,  3, N'magnatec'),
(5,  4, N'lốp tay ga'),
(6,  5, N'lốp côn tay'),
(7,  7, N'mũ fullface'),
(8,  9, N'mũ carbon'),
(9,  10, N'ắc quy khô'),
(10, 12, N'ắc quy AGM'),
(11, 13, N'phụ tùng Wave'),
(12, 16, N'gương Vario'),
(13, 18, N'đèn LED');
SET IDENTITY_INSERT ProductTags OFF;
GO

PRINT N'====================================================';
PRINT N'  SEED DATA HOÀN TẤT';
PRINT N'  - 5 đơn vị tính';
PRINT N'  - 6 danh mục';
PRINT N'  - 6 thương hiệu';
PRINT N'  - 18 sản phẩm (3/danh mục, 3/thương hiệu)';
PRINT N'  - 29 biến thể';
PRINT N'  - 36 ảnh sản phẩm + 58 ảnh biến thể';
PRINT N'  Nhớ chạy download_images.py để tải ảnh thật về local!';
PRINT N'====================================================';
GO
